<?php

namespace App\Controllers;

use App\Models\ArtikelModel;

class Artikel extends BaseController
{
    public function index()
    {
        $title = 'Daftar Artikel';
        $model = new ArtikelModel();
        $artikel = $model->findAll();

        return view('artikel/index', compact('artikel', 'title'));
    }

    public function admin_index()
    {
        $title = 'Admin | Daftar Artikel';
        $model = new ArtikelModel();
        
        $keyword = $this->request->getGet('keyword');
        $perPage = 5; // jumlah data per halaman
        
        if ($keyword) {
            $model->like('judul', $keyword)
                  ->orLike('isi', $keyword);
        }
        
        $artikel = $model->paginate($perPage);
        $pager = $model->pager;

        return view('artikel/admin_index', compact('artikel', 'title', 'keyword', 'pager'));
    }

    public function add()
    {
        $title = 'Tambah Artikel';
        return view('artikel/form_add', compact('title'));
    }

    public function save()
    {
        $model = new ArtikelModel();

        $data = [
            'judul' => $this->request->getPost('judul'),
            'isi'   => $this->request->getPost('isi'),
            'slug'  => url_title($this->request->getPost('judul'), '-', true),
        ];

        $file = $this->request->getFile('gambar');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move(ROOTPATH . 'public/gambar', $newName);
            $data['gambar'] = $newName;
        }

        $model->insert($data);

        return redirect()->to('/admin/artikel');
    }

    public function edit($id)
    {
        $model = new ArtikelModel();
        $data = $model->find($id);
        $title = 'Edit Artikel';

        if (!$data) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }

        return view('artikel/form_edit', compact('data', 'title'));
    }

    public function update($id)
    {
        $model = new ArtikelModel();

        $data = [
            'judul' => $this->request->getPost('judul'),
            'isi'   => $this->request->getPost('isi'),
            'slug'  => url_title($this->request->getPost('judul'), '-', true),
        ];

        $model->update($id, $data);

        return redirect()->to('/admin/artikel');
    }

    public function delete($id)
    {
        $model = new ArtikelModel();
        $model->delete($id);

        return redirect()->to('/admin/artikel');
    }
}