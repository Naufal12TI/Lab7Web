<?php
namespace App\Controllers;

class Page extends BaseController
{
    public function about()
    {
        return view('about', [
            'title' => 'Halaman About',
            'content' => 'Ini adalah halaman about yang menjelaskan tentang isi halaman ini.'
        ]);
    }

    public function contact()
    {
        return view('about', [
            'title' => 'Halaman Kontak',
            'content' => 'Ini adalah halaman Kontak. Silakan hubungi kami di sini.'
        ]);
    }

    public function faqs()
    {
        return view('about', [
            'title' => 'Halaman FAQs',
            'content' => 'Ini adalah halaman Frequently Asked Questions.'
        ]);
    }

    public function tos()
    {
        return view('about', [
            'title' => 'Term of Services',
            'content' => 'Ini adalah halaman Term of Services.'
        ]);
    }
}