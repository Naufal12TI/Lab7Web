<?= $this->include('template/header'); ?>

<h2><?= $title; ?></h2>

<form method="get">
    <input type="text" name="keyword" value="<?= $keyword ?? ''; ?>" placeholder="Cari judul atau isi...">
    <button type="submit">Cari</button>
    <?php if (isset($keyword) && $keyword !== ''): ?>
        <a href="<?= base_url('/admin/artikel'); ?>">Reset</a>
    <?php endif; ?>
</form>

<a href="<?= base_url('/admin/artikel/add'); ?>">+ Tambah Artikel</a>

<table border="1" cellpadding="10" cellspacing="0">
    <tr>
        <th>No</th>
        <th>Gambar</th>
        <th>Judul</th>
        <th>Aksi</th>
    </tr>
    <?php $no = 1; foreach($artikel as $row): ?>
    <tr>
        <td><?= $no++; ?></td>
        <td>
            <?php if(!empty($row['gambar'])): ?>
                <img src="<?= base_url('gambar/'.$row['gambar']); ?>" width="80">
            <?php else: ?>
                -
            <?php endif; ?>
        </td>
        <td><?= $row['judul']; ?></td>
        <td>
            <a href="<?= base_url('/admin/artikel/edit/' . $row['id']); ?>">Edit</a> | 
            <a href="<?= base_url('/admin/artikel/delete/' . $row['id']); ?>" onclick="return confirm('Yakin hapus artikel ini?')">Hapus</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<?= $pager->links(); ?>

<?= $this->include('template/footer'); ?>