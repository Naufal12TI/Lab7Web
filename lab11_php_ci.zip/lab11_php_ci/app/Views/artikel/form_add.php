<?= $this->include('template/header'); ?>

<h2><?= $title; ?></h2>

<form action="<?= base_url('/admin/artikel/save'); ?>" method="post" enctype="multipart/form-data">
    <p>
        <label>Judul</label><br>
        <input type="text" name="judul" style="width:100%">
    </p>
    <p>
        <label>Isi</label><br>
        <textarea name="isi" rows="10" style="width:100%"></textarea>
    </p>
    <p>
        <label>Gambar</label><br>
        <input type="file" name="gambar">
    </p>
    <p>
        <button type="submit">Simpan</button>
        <a href="<?= base_url('/admin/artikel'); ?>">Batal</a>
    </p>
</form>

<?= $this->include('template/footer'); ?>