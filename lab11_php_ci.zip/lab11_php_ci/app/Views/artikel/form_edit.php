<?= $this->include('template/header'); ?>

<h2><?= $title; ?></h2>

<form action="<?= base_url('/admin/artikel/update/' . $data['id']); ?>" method="post">
    <p>
        <label>Judul</label><br>
        <input type="text" name="judul" value="<?= $data['judul']; ?>" style="width:100%">
    </p>
    <p>
        <label>Isi</label><br>
        <textarea name="isi" rows="10" style="width:100%"><?= $data['isi']; ?></textarea>
    </p>
    <p>
        <button type="submit">Update</button>
        <a href="<?= base_url('/admin/artikel'); ?>">Batal</a>
    </p>
</form>

<?= $this->include('template/footer'); ?>