<?= $this->include('template/header'); ?>

<h2><?= $title; ?></h2>

<?php if($artikel): ?>
    <?php foreach($artikel as $row): ?>
        <article class="entry">
            <h2><?= $row['judul']; ?></h2>
            <p><?= substr($row['isi'], 0, 200); ?>...</p>
        </article>
        <hr>
    <?php endforeach; ?>
<?php else: ?>
    <p>Belum ada data artikel.</p>
<?php endif; ?>

<?= $this->include('template/footer'); ?>